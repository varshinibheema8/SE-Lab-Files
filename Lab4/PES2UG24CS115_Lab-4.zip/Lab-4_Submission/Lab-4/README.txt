Lab 4 - VibeCoding

Deliverables:
1. Lab4_Before.mp4 - before video
2. Lab4_After.mp4 - 10-second after video
3. Chat_History.pdf - compiled LLM prompts and development history

Updated code:
GitHub repository:
https://github.com/varshinibheema8/49-brick-breaker

The updated source code was committed and pushed to the personal GitHub repository.
