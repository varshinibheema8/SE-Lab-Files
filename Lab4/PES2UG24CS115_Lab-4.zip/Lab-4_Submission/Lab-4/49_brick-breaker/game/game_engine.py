import pygame
from .paddle import Paddle
from .ball import Ball
from .brick import Brick

# Game Engine

WHITE = (255, 255, 255)
BG = (15, 15, 25)

BRICK_COLORS = [
    (200, 60, 60),
    (200, 140, 60),
    (200, 200, 60),
    (80, 180, 80),
    (80, 140, 200),
]


class GameEngine:
    def __init__(self, width, height):
        self.width = width
        self.height = height

        self.paddle = Paddle(
            width // 2 - 50,
            height - 30,
            100,
            14
        )

        self.ball = Ball(
            width // 2,
            height - 50,
            radius=8
        )

        self.ball.vx = 4
        self.ball.vy = -4

        self.rows = 5
        self.cols = 8

        self.bricks = self._build_bricks(
            self.rows,
            self.cols
        )

        self.lives = 3
        self.score = 0

        self.font = pygame.font.SysFont(
            "Arial",
            28
        )

        self.result_font = pygame.font.SysFont(
            "Arial",
            56
        )

        self.result_score_font = pygame.font.SysFont(
            "Arial",
            32
        )

        self.game_over = False
        self.result = None

        # Task 3: difficulty menu
        self.difficulty_menu = False
        self.selected_difficulty = 0
        self.difficulties = [
            "Easy",
            "Medium",
            "Hard",
            "Exit"
        ]

        self.exit_requested = False

        # Task 4: sound effects
        pygame.mixer.init()

        self.brick_sound = pygame.mixer.Sound(
            "game/sounds/brick.mp3"
        )

        self.paddle_sound = pygame.mixer.Sound(
            "game/sounds/paddle.mp3"
        )

        self.wall_sound = pygame.mixer.Sound(
            "game/sounds/wall.mp3"
        )

        self.win_sound = pygame.mixer.Sound(
            "game/sounds/win.mp3"
        )

        self.gameover_sound = pygame.mixer.Sound(
            "game/sounds/gameover.mp3"
        )

    def _build_bricks(self, rows, cols):
        bricks = []

        margin = 30
        gap = 6
        top = 60

        brick_w = (
            self.width
            - margin * 2
            - gap * (cols - 1)
        ) // cols

        brick_h = 22

        for r in range(rows):
            for c in range(cols):
                x = margin + c * (
                    brick_w + gap
                )

                y = top + r * (
                    brick_h + gap
                )

                bricks.append(
                    Brick(
                        x,
                        y,
                        brick_w,
                        brick_h
                    )
                )

        return bricks

    def handle_event(self, event):

        # Task 3: difficulty menu
        if self.difficulty_menu:

            if event.type == pygame.KEYDOWN:

                if event.key in (
                    pygame.K_UP,
                    pygame.K_w
                ):
                    self.selected_difficulty = (
                        self.selected_difficulty - 1
                    ) % len(self.difficulties)

                elif event.key in (
                    pygame.K_DOWN,
                    pygame.K_s
                ):
                    self.selected_difficulty = (
                        self.selected_difficulty + 1
                    ) % len(self.difficulties)

                elif event.key in (
                    pygame.K_RETURN,
                    pygame.K_SPACE
                ):
                    choice = self.difficulties[
                        self.selected_difficulty
                    ]

                    if choice == "Exit":
                        self.exit_requested = True
                    else:
                        self.start_new_game(choice)

            return

        # After game over, open difficulty menu
        if self.game_over:

            if event.type == pygame.KEYDOWN:
                self.difficulty_menu = True
                self.selected_difficulty = 0

            return

    def handle_input(self):

        if self.game_over or self.difficulty_menu:
            return

        keys = pygame.key.get_pressed()

        if (
            keys[pygame.K_LEFT]
            or keys[pygame.K_a]
        ):
            self.paddle.move(
                -self.paddle.speed,
                self.width
            )

        if (
            keys[pygame.K_RIGHT]
            or keys[pygame.K_d]
        ):
            self.paddle.move(
                self.paddle.speed,
                self.width
            )

    def update(self):

        if self.game_over or self.difficulty_menu:
            return

        self.ball.move()

        # Wall collision
        if (
            self.ball.x - self.ball.radius <= 0
            or
            self.ball.x + self.ball.radius >= self.width
        ):
            self.ball.vx *= -1

            # Task 4: wall sound
            self.wall_sound.play()

        if (
            self.ball.y - self.ball.radius <= 0
        ):
            self.ball.vy *= -1

            # Task 4: wall sound
            self.wall_sound.play()

        # Paddle collision
        if self.ball.rect().colliderect(
            self.paddle.rect()
        ):
            self.ball.vy *= -1

            # Task 4: paddle sound
            self.paddle_sound.play()

        # Brick collision
        for brick in self.bricks:

            if (
                brick.alive
                and
                self.ball.rect().colliderect(
                    brick.rect()
                )
            ):

                brick.alive = False
                self.score += 1

                # Task 4: brick sound
                self.brick_sound.play()

                brick_rect = brick.rect()
                ball_rect = self.ball.rect()

                overlap_x = (
                    min(
                        ball_rect.right,
                        brick_rect.right
                    )
                    -
                    max(
                        ball_rect.left,
                        brick_rect.left
                    )
                )

                overlap_y = (
                    min(
                        ball_rect.bottom,
                        brick_rect.bottom
                    )
                    -
                    max(
                        ball_rect.top,
                        brick_rect.top
                    )
                )

                # Task 1:
                # Determine whether collision
                # was horizontal or vertical.
                if overlap_x < overlap_y:
                    self.ball.vx *= -1
                else:
                    self.ball.vy *= -1

                break

        # Ball fell below paddle
        if (
            self.ball.y - self.ball.radius
            > self.height
        ):

            self.lives -= 1

            if self.lives <= 0:

                self.game_over = True
                self.result = "lose"

                # Task 4: game-over sound
                self.gameover_sound.play()

            else:
                self._reset_ball()

        # Win condition
        if all(
            not b.alive
            for b in self.bricks
        ):

            self.game_over = True
            self.result = "win"

            # Task 4: win sound
            self.win_sound.play()

    def start_new_game(self, difficulty):

        # Reset game state
        self.game_over = False
        self.result = None

        self.difficulty_menu = False
        self.selected_difficulty = 0
        self.exit_requested = False

        self.score = 0
        self.lives = 3

        # Rebuild bricks
        self.bricks = self._build_bricks(
            self.rows,
            self.cols
        )

        # Reset paddle
        self.paddle.width = 100

        self.paddle.x = (
            self.width // 2
            - self.paddle.width // 2
        )

        # Apply difficulty
        if difficulty == "Easy":

            self.paddle.width = 120
            ball_speed = 4

        elif difficulty == "Medium":

            self.paddle.width = 100
            ball_speed = 5

        else:  # Hard

            self.paddle.width = 80
            ball_speed = 7

        # Reset ball
        self.ball.x = self.width // 2
        self.ball.y = self.height - 50

        self.ball.vx = ball_speed
        self.ball.vy = -ball_speed

    def _reset_ball(self):

        self.ball.x = self.width // 2
        self.ball.y = self.height - 50

        self.ball.vx = 4
        self.ball.vy = -4

    def render(self, screen):

        # Difficulty menu
        if self.difficulty_menu:

            self.render_difficulty_menu(screen)
            return

        screen.fill(BG)

        # Paddle
        pygame.draw.rect(
            screen,
            WHITE,
            self.paddle.rect()
        )

        # Ball
        pygame.draw.circle(
            screen,
            WHITE,
            (
                int(self.ball.x),
                int(self.ball.y)
            ),
            self.ball.radius
        )

        # Bricks
        for i, brick in enumerate(
            self.bricks
        ):

            if brick.alive:

                row = i // self.cols

                color = BRICK_COLORS[
                    row % len(BRICK_COLORS)
                ]

                pygame.draw.rect(
                    screen,
                    color,
                    brick.rect()
                )

        # Score
        score_text = self.font.render(
            f"Score: {self.score}",
            True,
            WHITE
        )

        screen.blit(
            score_text,
            (10, 10)
        )

        # Lives
        lives_text = self.font.render(
            f"Lives: {self.lives}",
            True,
            WHITE
        )

        screen.blit(
            lives_text,
            (self.width - 130, 10)
        )

        # Game over / win screen
        if self.game_over:

            if self.result == "win":
                result_text = "YOU WIN!"
            else:
                result_text = "GAME OVER"

            result_surface = (
                self.result_font.render(
                    result_text,
                    True,
                    WHITE
                )
            )

            score_surface = (
                self.result_score_font.render(
                    f"Final Score: {self.score}",
                    True,
                    WHITE
                )
            )

            prompt_surface = (
                self.result_score_font.render(
                    "Press any key for difficulty menu",
                    True,
                    WHITE
                )
            )

            result_rect = (
                result_surface.get_rect(
                    center=(
                        self.width // 2,
                        self.height // 2 - 60
                    )
                )
            )

            score_rect = (
                score_surface.get_rect(
                    center=(
                        self.width // 2,
                        self.height // 2
                    )
                )
            )

            prompt_rect = (
                prompt_surface.get_rect(
                    center=(
                        self.width // 2,
                        self.height // 2 + 60
                    )
                )
            )

            screen.blit(
                result_surface,
                result_rect
            )

            screen.blit(
                score_surface,
                score_rect
            )

            screen.blit(
                prompt_surface,
                prompt_rect
            )

    def render_difficulty_menu(self, screen):

        screen.fill(BG)

        # Title
        title = self.result_font.render(
            "Choose Difficulty",
            True,
            WHITE
        )

        title_rect = title.get_rect(
            center=(
                self.width // 2,
                100
            )
        )

        screen.blit(
            title,
            title_rect
        )

        # Difficulty options
        for index, difficulty in enumerate(
            self.difficulties
        ):

            if (
                index
                == self.selected_difficulty
            ):

                text = f"> {difficulty} <"
                color = (255, 255, 0)

            else:

                text = difficulty
                color = WHITE

            surface = (
                self.result_score_font.render(
                    text,
                    True,
                    color
                )
            )

            rect = surface.get_rect(
                center=(
                    self.width // 2,
                    200 + index * 60
                )
            )

            screen.blit(
                surface,
                rect
            )

        # Instructions
        prompt = (
            self.result_score_font.render(
                "Use Up/Down and Enter",
                True,
                WHITE
            )
        )

        prompt_rect = prompt.get_rect(
            center=(
                self.width // 2,
                self.height - 50
            )
        )

        screen.blit(
            prompt,
            prompt_rect
        )